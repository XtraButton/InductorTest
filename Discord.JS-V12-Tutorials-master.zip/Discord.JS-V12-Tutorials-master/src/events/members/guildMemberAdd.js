module.exports = (client, member) => {
    console.log('Guild member add was registered.');
};