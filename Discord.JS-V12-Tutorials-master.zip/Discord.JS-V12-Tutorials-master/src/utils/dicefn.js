const rollDice = () => Math.floor(Math.random() * 6) + 1;

module.exports = { rollDice };